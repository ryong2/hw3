#!/bin/bash


jobId1=$(sbatch --output="slurm_out/slurm-%A_%a.out" getData.sh)
# "Submitted batch job 6768660" (where the number changes from job to job).
jobId1=$(echo $jobId1 | sed 's/Submitted batch job //')

jobId2=$(sbatch --array=1-3 --output="slurm_out/slurm-%A_%a.out" --dependency=afterany:$jobId1 jobArray.sh)
jobId2=$(echo $jobId2 | sed 's/Submitted batch job //') # Strip off "Submitted batch job ".

jobId3=$(sbatch --output="slurm_out/slurm-%A_%a.out" --dependency=afterany:$jobId2 findLightest.sh)
