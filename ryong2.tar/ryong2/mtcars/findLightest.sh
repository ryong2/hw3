#!/bin/bash

rm -rf out

cat out*.csv | sort -n | head -1 > out
