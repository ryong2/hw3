#!/bin/bash

rm -rf allMSN.csv
cat MSN*.csv > allMSN.csv
