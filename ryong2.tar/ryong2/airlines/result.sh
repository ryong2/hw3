#!/bin/bash
rm -rf out

echo 'how far can you get from madison in one filght?' > out
cat allMSN.csv | cut -d, -f 3,4,5 | sort -n -t, -k3 | tail -1 >> out

echo 'what is the average departure delay for each day of the week?' >> out

echo 'Mo Tu We Th Fr Sa Su' >> out

module load R/R-3.6.1

Rscript -e "data=read.csv('allMSN.csv',header=1) ; result=tapply(data[,2],data[,1],mean,na.rm=1) ; write(round(result[1:7],1),file='out',ncolumns=7,append=1)"




